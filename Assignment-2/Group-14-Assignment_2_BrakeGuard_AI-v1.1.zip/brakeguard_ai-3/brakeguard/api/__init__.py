"""FastAPI REST layer."""

from .app import create_app

__all__ = ["create_app"]
